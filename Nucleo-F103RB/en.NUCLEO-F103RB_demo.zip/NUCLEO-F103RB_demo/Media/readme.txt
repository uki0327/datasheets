This directory contains a set of images (*.bmp) and audio file to be used
with the following demonstration:
   - \Projects\STM32F103RB-Nucleo\Demonstrations\Adafruit_LCD_1_8_SD_Joystick

And example:
   - file Audio\musicsample_wav.bin in .\Projects\STM3210C_EVAL\Examples\I2S\I2S_Audio
   - file Audio\audio.bin in 
      * .\Projects\STM3210C_EVAL\Examples\BSP
      * .\Projects\STM3210E_EVAL\Examples\BSP