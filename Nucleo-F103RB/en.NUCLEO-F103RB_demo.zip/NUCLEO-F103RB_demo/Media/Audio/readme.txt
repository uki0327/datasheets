The provided sample Audio file (stored in internal Flash memory) is extracted from:
- Title: artofgardens-instr 
- Artist/Composer: Dan O'Connor
- Creative Commons license: Attribution 3.0 United States
Please read the license following this link:
http://creativecommons.org/licenses/by/3.0/us/
